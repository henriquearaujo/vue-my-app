<!-- src/components/Footer.vue -->
<template>
  <footer class="w-full bg-white border-t">
    <div class="max-w-6xl mx-auto px-4 py-6 text-center text-gray-600 text-sm">
      © {{ new Date().getFullYear() }} My Vue App — Todos os direitos reservados.
    </div>
  </footer>
</template>

<script setup></script>

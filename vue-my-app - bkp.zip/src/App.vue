<!-- src/App.vue -->
<template>
  <MainLayout>
    <RouterView />
  </MainLayout>
</template>

<script setup>
import MainLayout from './layouts/MainLayout.vue'
</script>

<style>
/* estilos globais extras podem ir aqui, caso necessário */
</style>

<!-- src/pages/Home.vue -->
<template>
  <section class="space-y-6">
    <h2 class="text-3xl font-bold text-gray-800">Bem-vindo ao site!</h2>

    <div class="p-10 bg-red-500 text-white">
  TESTE DO TAILWIND
</div>


    <p class="text-gray-600 leading-relaxed">
      Esta é a página inicial do seu projeto Vue 3 + Vite + Tailwind v4.
      Tudo organizado, moderno e pronto para expandir.
    </p>

    <div class="p-6 bg-white shadow rounded-lg border">
      <h3 class="text-xl font-semibold mb-2">Tecnologias usadas</h3>
      <ul class="list-disc pl-6 text-gray-700">
        <li>Vue 3 (script setup)</li>
        <li>Vite (build ultra rápido)</li>
        <li>TailwindCSS v4</li>
        <li>Arquitetura moderna com layouts + rotas</li>
      </ul>
    </div>
  </section>
</template>

<!-- src/pages/Sobre.vue -->
<template>
  <section class="space-y-6">
    <h2 class="text-3xl font-bold text-gray-800">Sobre o Projeto</h2>

    <p class="text-gray-600 leading-relaxed">
      Este projeto foi criado para estudos práticos do Vue 3 com Tailwind e
      arquitetura profissional. Aqui você pode expandir com MongoDB, APIs,
      autenticação e muito mais.
    </p>

    <p class="text-gray-600 leading-relaxed">
      O objetivo é construir uma base sólida, organizada e escalável — exatamente
      como em um projeto real de mercado.
    </p>
  </section>
</template>

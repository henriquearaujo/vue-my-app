<!-- src/pages/NotFound.vue -->
<template>
  <div class="text-center py-20">
    <h2 class="text-5xl font-bold text-gray-800">404</h2>
    <p class="text-gray-600 mt-4">Página não encontrada.</p>

    <RouterLink
      to="/"
      class="mt-8 inline-block bg-blue-600 text-white px-5 py-2 rounded hover:bg-blue-700 transition"
    >
      Voltar para Home
    </RouterLink>
  </div>
</template>
